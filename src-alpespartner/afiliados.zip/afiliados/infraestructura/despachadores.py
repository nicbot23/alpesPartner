class Despachador:
    def publicar_evento(self, evento, topico):
        # Aquí iría la lógica para publicar el evento en Pulsar
        print(f"Evento publicado en {topico}: {evento}")
