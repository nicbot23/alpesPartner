# BFF (Backend For Frontend) para AlpesPartner
# Enfoque: Simple orquestador que delega sagas al microservicio de campanias